# BFS Mermaid Diagram Standard — Unified Prompt Kit

## About This Document

This is a consolidated, best-of-breed standard for producing visually consistent, brand-aligned Mermaid diagrams through Microsoft 365 Copilot. It synthesizes research and recommendations from four independent AI analysis passes (Claude, ChatGPT, Copilot, Perplexity) against the same source material — three production BFS Mermaid diagrams and the official Mermaid v11.13 documentation.

The purpose is to give M365 Copilot everything it needs — in one document — to generate diagrams that look like they came from a reusable enterprise template rather than a one-off generated artifact.

### How To Use This Document

Save this document where you can access it easily — a Loop page, OneNote, or a text snippet tool. When you want Copilot to generate a Mermaid diagram, go to Part 7 and paste the appropriate prompt template into your Copilot chat. The prompt templates contain the full style contract inline, so Copilot receives the complete visual system in every request. Parts 1–6 are reference material for you; Parts 7–9 are what Copilot consumes directly.

---

## Part 1: Design Philosophy

Treat Mermaid styling the same way you treat PowerPoint: fixed theme, fixed shape styles, dynamic content. The visual system is infrastructure. The nodes and edges are content. Copilot should never be allowed to freestyle styling.

This standard enforces three layers of visual control:

1. **YAML frontmatter / init directive** — controls the global canvas: background, fonts, default colors, cluster appearance, edge colors. This is the "page layout" layer.
2. **classDef library** — controls node-level styling through semantic role assignment. This is the "shape styles" layer. Copilot assigns classes based on what a node *does*, not what vendor it belongs to.
3. **Subgraph style tiers** — controls container/boundary appearance through inline style statements. This is the "section formatting" layer.

Between these three layers, there is no room for Copilot to hallucinate colors.

### Key Principles

- White is the default node fill — colored fills signal semantic meaning via classDef
- Blue depth signals ownership — deeper blue = platform/system; lighter blue = guidance/overlay; gray = BFS-owned context
- Dashed strokes signal conditionality — gates use dash patterns; open questions use wider dashes
- Red is reserved for exclusion/warning only — never decorative
- Stroke width creates hierarchy — 1px chrome, 1.4–1.5px standard, 1.8–2px emphasis
- White text on dark fills; dark text on light fills
- Edge labels always get white backgrounds for readability
- Canvas is warm gray (#E7E6E6), not white — creates visual separation from the page

---

## Part 2: Master Color Palette

All values are hex. Mermaid's theming engine does not recognize named colors.

### Core Brand Blues

| Name | Hex | Role |
|------|-----|------|
| Builders Blue | `#00205B` | Primary brand anchor — borders, text on light fills, subgraph strokes, title color |
| Medium Blue | `#003087` | Secondary brand — strokes on lighter blue fills, tertiary subgraph strokes |
| Deep Blue | `#002F86` | Edge lines, cluster borders, default link color, canvas-level line color |
| Accent Blue | `#307FE2` | Emphasis/highlight nodes (use sparingly) |
| Electric Blue | `#2F7FE1` | Interchangeable with Accent Blue; paired stroke `#1F6FCF` |

### Support Blues

| Name | Hex | Role |
|------|-----|------|
| Support Blue Medium | `#B3C1DB` | System/app node fills, secondary backgrounds, Tier 2 subgraph fills |
| Support Blue Light | `#D6E5F9` | AI/overlay/guidance fills, tertiary backgrounds, scope markers |

### Grays and Neutrals

| Name | Hex | Role |
|------|-----|------|
| Support Gray Light | `#D0D0CE` | BFS-owned context fills, boundary nodes, Tier 1/3 subgraph fills |
| Panel Gray | `#F2F2F2` | Cluster interior backgrounds (lighter than canvas) |
| Canvas Gray | `#E7E6E6` | Overall diagram background |
| White | `#FFFFFF` | Default node fill, gate/control/log nodes, edge label backgrounds |
| Border Gray | `#A7A8A9` | Gate/control borders, dashed strokes, neutral chrome |
| Medium Gray | `#75787B` | Boundary strokes, identity/audit subgraph strokes |
| Slate | `#515151` | Dark fill for infrastructure/database emphasis (paired stroke `#3A3A3A`) |
| Text Gray | `#4D4D4D` | Primary body text on light backgrounds |
| Dark Text | `#333333` | General text, themeVariables default text color |

### Signal / Exception

| Name | Hex | Role |
|------|-----|------|
| BFS Red | `#C8102E` | Out-of-scope, exclusion, warning, risk (paired stroke `#9F0D24`) |

### Typography

| Property | Value |
|----------|-------|
| Font Family | `Segoe UI, Arial, Helvetica, sans-serif` |
| Font Size | `14px` |

---

## Part 3: Theme Configuration Blocks

Two formats are provided. **YAML frontmatter** is the current Mermaid standard (v10.5+). The **init directive** is deprecated but still functional, and may render more reliably in Microsoft Loop, which can lag behind current Mermaid versions.

**Important:** Use one or the other. Never include both in the same diagram.

### Option A: YAML Frontmatter (Preferred)

```
---
config:
  theme: base
  look: classic
  themeVariables:
    background: "#E7E6E6"
    fontFamily: "Segoe UI, Arial, Helvetica, sans-serif"
    fontSize: "14px"
    textColor: "#333333"
    lineColor: "#002F86"
    clusterBorder: "#002F86"
    titleColor: "#002F86"
    primaryColor: "#FFFFFF"
    primaryBorderColor: "#A7A8A9"
    primaryTextColor: "#333333"
    secondaryColor: "#B3C1DB"
    secondaryBorderColor: "#00205B"
    secondaryTextColor: "#00205B"
    tertiaryColor: "#E7E6E6"
    tertiaryBorderColor: "#75787B"
    tertiaryTextColor: "#4D4D4D"
    edgeLabelBackground: "#FFFFFF"
    clusterBkg: "#F2F2F2"
    mainBkg: "#FFFFFF"
    nodeBorder: "#A7A8A9"
    nodeTextColor: "#333333"
    noteBkgColor: "#D6E5F9"
    noteTextColor: "#00205B"
    noteBorderColor: "#003087"
    actorBkg: "#FFFFFF"
    actorBorder: "#00205B"
    actorTextColor: "#00205B"
    signalColor: "#333333"
    labelBoxBkgColor: "#B3C1DB"
    labelBoxBorderColor: "#00205B"
---
```

### Option B: Init Directive (Loop/Legacy Fallback)

This must be a single line. The diagram type declaration must immediately follow on the next line.

```
%%{init: {"theme":"base","themeVariables":{"background":"#E7E6E6","fontFamily":"Segoe UI, Arial, Helvetica, sans-serif","fontSize":"14px","textColor":"#333333","lineColor":"#002F86","clusterBorder":"#002F86","titleColor":"#002F86","primaryColor":"#FFFFFF","primaryBorderColor":"#A7A8A9","primaryTextColor":"#333333","secondaryColor":"#B3C1DB","secondaryBorderColor":"#00205B","secondaryTextColor":"#00205B","tertiaryColor":"#E7E6E6","tertiaryBorderColor":"#75787B","tertiaryTextColor":"#4D4D4D","edgeLabelBackground":"#FFFFFF","clusterBkg":"#F2F2F2","mainBkg":"#FFFFFF","nodeBorder":"#A7A8A9","nodeTextColor":"#333333","noteBkgColor":"#D6E5F9","noteTextColor":"#00205B","noteBorderColor":"#003087","actorBkg":"#FFFFFF","actorBorder":"#00205B","actorTextColor":"#00205B","signalColor":"#333333","labelBoxBkgColor":"#B3C1DB","labelBoxBorderColor":"#00205B"}}}%%
```

---

## Part 4: Semantic Class Library

Classes are organized by visual role, not by vendor or product. This keeps the system reusable across any diagram subject. Include only the classes relevant to a given diagram.

### Structural / Contextual

```
classDef primary     fill:#D0D0CE,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef secondary   fill:#B3C1DB,stroke:#00205B,stroke-width:1.5px,color:#00205B
classDef tertiary    fill:#D6E5F9,stroke:#003087,stroke-width:1.5px,color:#00205B
classDef platform    fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef boundary    fill:#D0D0CE,stroke:#75787B,stroke-width:1.5px,color:#4D4D4D
```

### People and Entry Points

```
classDef actor       fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#00205B
```

### Governance / Chrome

```
classDef gate        fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,stroke-dasharray:4 3,color:#4D4D4D
classDef control     fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef log         fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef question    fill:#FFFFFF,stroke:#00205B,stroke-width:1px,stroke-dasharray:6 4,color:#00205B
```

### Emphasis / Highlight

```
classDef accent      fill:#2F7FE1,stroke:#1F6FCF,stroke-width:1.4px,color:#FFFFFF
classDef deepBlue    fill:#002F86,stroke:#002F86,stroke-width:1.4px,color:#FFFFFF
classDef slate       fill:#515151,stroke:#3A3A3A,stroke-width:1.4px,color:#FFFFFF
classDef dbStrong    stroke-width:1.8px
```

### Scope / Signal

```
classDef scope       fill:#D6E5F9,stroke:#00205B,stroke-width:2px,color:#00205B
classDef outOfScope  fill:#FFFFFF,stroke:#C8102E,stroke-width:2px,color:#C8102E
classDef redDash     fill:#C8102E,stroke:#9F0D24,stroke-dasharray:3 2,stroke-width:1.5px,color:#FFFFFF
```

### Class-to-Role Mapping Guide

When Copilot generates a diagram, it should assign classes based on these semantic roles:

| Class | Use For |
|-------|---------|
| `primary` | BFS-owned context, internal enterprise elements, business-side nodes |
| `secondary` | Primary application surfaces, tenant UIs, core platform elements |
| `tertiary` | Overlays, assistive experiences, AI features, guidance layers |
| `platform` | Neutral platform/infrastructure components |
| `boundary` | Administrative boundaries, trust zones, governance containers |
| `actor` | People, teams, user endpoints, human roles |
| `gate` | Prerequisites, eligibility conditions, enablement dependencies |
| `control` | Admin toggles, lifecycle controls, kill switches, configuration |
| `log` | Audit, logging, telemetry, monitoring, review, detection |
| `question` | TBDs, unresolved dependencies, open design questions |
| `accent` | Rare emphasis only — highlights, focal points |
| `deepBlue` | Deep brand emphasis for key infrastructure or channel nodes |
| `slate` | Dark emphasis for database/persistence or infrastructure contrast |
| `scope` | In-scope framing, scope guardrails, approved focus areas |
| `outOfScope` | Explicit exclusions, out-of-scope markers |
| `redDash` | Risk hotspots, exception warnings (filled red, not just bordered) |

---

## Part 5: Subgraph Styling Tiers

Apply using inline `style` statements after each subgraph block. Select the tier that matches the subgraph's role.

| Tier | Fill | Stroke | Width | Text Color | Use For |
|------|------|--------|-------|------------|---------|
| 1 — Major boundary | `#D0D0CE` | `#00205B` | 2px | `#4D4D4D` | BFS-owned context, major platform boundaries |
| 2 — System tenant | `#B3C1DB` | `#00205B` | 2px | `#00205B` | Primary application tenants, SaaS boundaries |
| 2b — Light system | `#D6E5F9` | `#003087` | 2px | `#00205B` | Secondary/overlay planes, guidance layers |
| 3 — Interior group | `#D0D0CE` | `#75787B` | 2px | `#4D4D4D` | Nested compartments, identity planes, audit groups |
| 3b — Chrome group | `#FFFFFF` | `#A7A8A9` | 2px | `#4D4D4D` | Gates, open questions, neutral chrome groups |
| 4 — Environment | `#F2F2F2` | `#002F86` | 1.5px | `#002F86` | Dev/QA/Prod panels, neutral environment containers |

---

## Part 6: Edge and Link Styling

| Syntax | Usage |
|--------|-------|
| `-->` | Primary flow, data movement, control signals |
| `-.->` | Optional paths, provisioning, log export, boundary anchors |
| `-->\|"Label"\|` | Named solid relationships |
| `-. "Label" .->` | Named optional/guidance flows |
| `linkStyle default stroke:#002F86,stroke-width:1.3px` | Brand-default edge style (include in every flowchart) |

### Shape Conventions

| Shape | Use For |
|-------|---------|
| `((Circle))` or `((Double circle))` | Actors, people, human roles |
| `["Rectangle"]` | Standard systems, apps, UI surfaces, features |
| `[["Subroutine"]]` | Runtime services, platform tiers, execution layers |
| `[("Cylinder")]` | Databases, persistent stores, data repositories |
| `{"Diamond"}` | Decision nodes (use only when true branching logic applies) |
| `(["Stadium/pill"])` | External dependencies, optional integrations, soft endpoints |

---

## Part 7: Reusable Prompt Templates

These are the prompts you actually paste into Copilot. Each one contains the full style contract inline.

---

### PROMPT A — Thread Opener (Iterative Build)

Use this to start a dedicated Copilot chat thread for building a diagram iteratively.

```
This thread is for creating and iteratively refining a single Mermaid diagram. Every diagram you generate in this thread must follow the rules below exactly.

OUTPUT RULES (non-negotiable):
1. Return EXACTLY ONE fenced ```mermaid``` code block and nothing else. No prose, no bullets, no explanation outside the code block.
2. Begin the diagram with the YAML frontmatter below. Include it verbatim. Do NOT modify any values.
3. After the frontmatter and diagram type declaration, include the classDef block and linkStyle default exactly as shown. Include only the classes relevant to this diagram.
4. Do NOT invent colors, fills, gradients, fonts, styles, classDefs, or inline style overrides beyond what is defined below.
5. Style every subgraph with an explicit inline style statement using only the approved tier patterns listed below.
6. Use short stable node IDs (alphanumeric and underscores only). Put all human-readable text in double-quoted labels.
7. Any label containing punctuation, parentheses, slashes, colons, angle brackets, or special characters MUST be wrapped in double quotes.
8. Do NOT use HTML tags (<br>, <b>, <i>) inside labels. Keep labels single-line.
9. Do NOT use semicolons as line terminators.
10. Never use the lowercase word "end" as a node label or node ID.
11. Every subgraph must have both a quoted label and an explicit end keyword.
12. When I request changes, regenerate the FULL diagram — never output partial fragments or diffs.
13. Before returning, silently verify: no duplicate IDs, no orphan nodes, no unmatched brackets, no dangling edges, no reserved-word collisions.

YAML FRONTMATTER (paste verbatim as the first lines of the mermaid block):
---
config:
  theme: base
  look: classic
  themeVariables:
    background: "#E7E6E6"
    fontFamily: "Segoe UI, Arial, Helvetica, sans-serif"
    fontSize: "14px"
    textColor: "#333333"
    lineColor: "#002F86"
    clusterBorder: "#002F86"
    titleColor: "#002F86"
    primaryColor: "#FFFFFF"
    primaryBorderColor: "#A7A8A9"
    primaryTextColor: "#333333"
    secondaryColor: "#B3C1DB"
    secondaryBorderColor: "#00205B"
    secondaryTextColor: "#00205B"
    tertiaryColor: "#E7E6E6"
    tertiaryBorderColor: "#75787B"
    tertiaryTextColor: "#4D4D4D"
    edgeLabelBackground: "#FFFFFF"
    clusterBkg: "#F2F2F2"
    mainBkg: "#FFFFFF"
    nodeBorder: "#A7A8A9"
    nodeTextColor: "#333333"
---

APPROVED classDef LIBRARY (include only those relevant to this diagram):
classDef primary     fill:#D0D0CE,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef secondary   fill:#B3C1DB,stroke:#00205B,stroke-width:1.5px,color:#00205B
classDef tertiary    fill:#D6E5F9,stroke:#003087,stroke-width:1.5px,color:#00205B
classDef platform    fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef boundary    fill:#D0D0CE,stroke:#75787B,stroke-width:1.5px,color:#4D4D4D
classDef actor       fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#00205B
classDef gate        fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,stroke-dasharray:4 3,color:#4D4D4D
classDef control     fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef log         fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef question    fill:#FFFFFF,stroke:#00205B,stroke-width:1px,stroke-dasharray:6 4,color:#00205B
classDef accent      fill:#2F7FE1,stroke:#1F6FCF,stroke-width:1.4px,color:#FFFFFF
classDef deepBlue    fill:#002F86,stroke:#002F86,stroke-width:1.4px,color:#FFFFFF
classDef slate       fill:#515151,stroke:#3A3A3A,stroke-width:1.4px,color:#FFFFFF
classDef dbStrong    stroke-width:1.8px
classDef scope       fill:#D6E5F9,stroke:#00205B,stroke-width:2px,color:#00205B
classDef outOfScope  fill:#FFFFFF,stroke:#C8102E,stroke-width:2px,color:#C8102E
classDef redDash     fill:#C8102E,stroke:#9F0D24,stroke-dasharray:3 2,stroke-width:1.5px,color:#FFFFFF

DEFAULT EDGE STYLE (include in every flowchart):
linkStyle default stroke:#002F86,stroke-width:1.3px

APPROVED SUBGRAPH STYLE TIERS (apply one per subgraph using inline style):
  Major boundary:   style ID fill:#D0D0CE,stroke:#00205B,stroke-width:2px,color:#4D4D4D
  System tenant:    style ID fill:#B3C1DB,stroke:#00205B,stroke-width:2px,color:#00205B
  Light system:     style ID fill:#D6E5F9,stroke:#003087,stroke-width:2px,color:#00205B
  Interior group:   style ID fill:#D0D0CE,stroke:#75787B,stroke-width:2px,color:#4D4D4D
  Chrome group:     style ID fill:#FFFFFF,stroke:#A7A8A9,stroke-width:2px,color:#4D4D4D
  Environment:      style ID fill:#F2F2F2,stroke:#002F86,stroke-width:1.5px,color:#002F86

CLASS ASSIGNMENT RULES:
  primary = BFS-owned context, internal enterprise elements
  secondary = primary application surfaces, tenant UIs, core platform
  tertiary = overlays, AI features, guidance layers, assistive experiences
  platform = neutral infrastructure, platform components
  boundary = trust zones, ownership zones, governance containers
  actor = people, teams, user endpoints
  gate = prerequisites, eligibility conditions, enablement dependencies
  control = admin toggles, lifecycle controls, kill switches
  log = audit, logging, telemetry, monitoring, detection
  question = TBDs, unresolved dependencies, open design questions
  accent/deepBlue/slate = visual emphasis (use sparingly and intentionally)
  scope = in-scope framing, approved focus areas
  outOfScope = explicit exclusions, prohibited items
  redDash = risk hotspots, exception warnings

QUALITY BAR:
The diagram should feel BFS-branded, restrained, professional, and executive-readable. It should look like it came from a reusable template, not a one-off generation. Do not create rainbow diagrams.

DIAGRAM TYPE: [SPECIFY: flowchart LR / flowchart TD / sequenceDiagram / etc.]

TOPIC: [DESCRIBE THE SUBJECT]
```

---

### PROMPT B — Drop-In Generator (Context-Based)

Use this when a chat thread already has content and you want to generate a diagram from that context.

```
Based on the content discussed in this thread, generate a Mermaid diagram.

OUTPUT RULES (non-negotiable):
1. Return EXACTLY ONE fenced ```mermaid``` code block and nothing else.
2. Begin with the YAML frontmatter below — include verbatim, do not modify.
3. Include the classDef block (only relevant classes) and linkStyle default exactly as shown.
4. Do NOT invent colors, styles, classDefs, or inline overrides beyond what is defined below.
5. Style every subgraph with an approved tier pattern.
6. Use short stable node IDs and double-quoted labels.
7. Quote any label with punctuation or special characters.
8. No HTML tags in labels. No semicolons. No lowercase "end" as a label.
9. Every subgraph needs a quoted label and explicit end keyword.
10. Silently verify syntax before returning.

YAML FRONTMATTER:
---
config:
  theme: base
  look: classic
  themeVariables:
    background: "#E7E6E6"
    fontFamily: "Segoe UI, Arial, Helvetica, sans-serif"
    fontSize: "14px"
    textColor: "#333333"
    lineColor: "#002F86"
    clusterBorder: "#002F86"
    titleColor: "#002F86"
    primaryColor: "#FFFFFF"
    primaryBorderColor: "#A7A8A9"
    primaryTextColor: "#333333"
    secondaryColor: "#B3C1DB"
    secondaryBorderColor: "#00205B"
    secondaryTextColor: "#00205B"
    tertiaryColor: "#E7E6E6"
    tertiaryBorderColor: "#75787B"
    tertiaryTextColor: "#4D4D4D"
    edgeLabelBackground: "#FFFFFF"
    clusterBkg: "#F2F2F2"
    mainBkg: "#FFFFFF"
    nodeBorder: "#A7A8A9"
    nodeTextColor: "#333333"
---

APPROVED CLASSES (include only relevant ones):
classDef primary     fill:#D0D0CE,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef secondary   fill:#B3C1DB,stroke:#00205B,stroke-width:1.5px,color:#00205B
classDef tertiary    fill:#D6E5F9,stroke:#003087,stroke-width:1.5px,color:#00205B
classDef platform    fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#4D4D4D
classDef boundary    fill:#D0D0CE,stroke:#75787B,stroke-width:1.5px,color:#4D4D4D
classDef actor       fill:#FFFFFF,stroke:#00205B,stroke-width:1.5px,color:#00205B
classDef gate        fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,stroke-dasharray:4 3,color:#4D4D4D
classDef control     fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef log         fill:#FFFFFF,stroke:#A7A8A9,stroke-width:1px,color:#4D4D4D
classDef question    fill:#FFFFFF,stroke:#00205B,stroke-width:1px,stroke-dasharray:6 4,color:#00205B
classDef accent      fill:#2F7FE1,stroke:#1F6FCF,stroke-width:1.4px,color:#FFFFFF
classDef deepBlue    fill:#002F86,stroke:#002F86,stroke-width:1.4px,color:#FFFFFF
classDef slate       fill:#515151,stroke:#3A3A3A,stroke-width:1.4px,color:#FFFFFF
classDef dbStrong    stroke-width:1.8px
classDef scope       fill:#D6E5F9,stroke:#00205B,stroke-width:2px,color:#00205B
classDef outOfScope  fill:#FFFFFF,stroke:#C8102E,stroke-width:2px,color:#C8102E
classDef redDash     fill:#C8102E,stroke:#9F0D24,stroke-dasharray:3 2,stroke-width:1.5px,color:#FFFFFF

linkStyle default stroke:#002F86,stroke-width:1.3px

SUBGRAPH TIERS:
  Major boundary:   style ID fill:#D0D0CE,stroke:#00205B,stroke-width:2px,color:#4D4D4D
  System tenant:    style ID fill:#B3C1DB,stroke:#00205B,stroke-width:2px,color:#00205B
  Light system:     style ID fill:#D6E5F9,stroke:#003087,stroke-width:2px,color:#00205B
  Interior group:   style ID fill:#D0D0CE,stroke:#75787B,stroke-width:2px,color:#4D4D4D
  Chrome group:     style ID fill:#FFFFFF,stroke:#A7A8A9,stroke-width:2px,color:#4D4D4D
  Environment:      style ID fill:#F2F2F2,stroke:#002F86,stroke-width:1.5px,color:#002F86

DIAGRAM TYPE: [flowchart LR / flowchart TD / sequenceDiagram / etc.]
```

---

### PROMPT C — Init Directive Variant (Loop Fallback)

If YAML frontmatter fails to render in your target surface, replace the frontmatter instruction in Prompt A or B with this. The init directive must be a single line and must be the first line inside the mermaid code block.

```
Instead of YAML frontmatter, use this exact single-line init directive as the FIRST line of the mermaid block:

%%{init: {"theme":"base","themeVariables":{"background":"#E7E6E6","fontFamily":"Segoe UI, Arial, Helvetica, sans-serif","fontSize":"14px","textColor":"#333333","lineColor":"#002F86","clusterBorder":"#002F86","titleColor":"#002F86","primaryColor":"#FFFFFF","primaryBorderColor":"#A7A8A9","primaryTextColor":"#333333","secondaryColor":"#B3C1DB","secondaryBorderColor":"#00205B","secondaryTextColor":"#00205B","tertiaryColor":"#E7E6E6","tertiaryBorderColor":"#75787B","tertiaryTextColor":"#4D4D4D","edgeLabelBackground":"#FFFFFF","clusterBkg":"#F2F2F2","mainBkg":"#FFFFFF","nodeBorder":"#A7A8A9","nodeTextColor":"#333333","noteBkgColor":"#D6E5F9","noteTextColor":"#00205B","noteBorderColor":"#003087","actorBkg":"#FFFFFF","actorBorder":"#00205B","actorTextColor":"#00205B","signalColor":"#333333","labelBoxBkgColor":"#B3C1DB","labelBoxBorderColor":"#00205B"}}}%%

The diagram type declaration must immediately follow on the next line. Do not add line breaks inside the init directive.
```

---

### PROMPT D — Iterative Update

Use this after a diagram already exists in the thread and you want to modify it.

```
Update the existing Mermaid diagram using the new information from this conversation.

Rules:
- Preserve the theme/config block exactly as-is.
- Preserve all classDef lines exactly as-is.
- Preserve the linkStyle default exactly as-is.
- Use only the approved classes and subgraph tier patterns.
- Return the FULL updated diagram, not a diff or fragment.
- Only change nodes, edges, labels, and subgraphs that must change.
- Do not introduce new colors, styles, or classDefs.
- Silently verify syntax before returning.
- Output only one fenced mermaid code block and nothing else.
```

---

### PROMPT E — Syntax Repair

Use this when Copilot produces Mermaid that fails to render, rather than asking for a full rewrite.

```
Repair the Mermaid syntax only.

Rules:
- Keep the theme/config block unchanged.
- Keep all colors, classes, and linkStyle unchanged.
- Fix only syntax: IDs, brackets, arrows, subgraph structure, reserved-word issues, quoting.
- Do not add or remove nodes unless required to fix a broken edge.
- Do not change the visual style in any way.
- Output only one corrected fenced mermaid code block and nothing else.
```

---

## Part 8: Sequence Diagram Styling Guidance

Sequence diagrams have a narrower styling surface than flowcharts. The YAML frontmatter in Part 3 already includes sequence-specific themeVariables (actorBkg, actorBorder, actorTextColor, signalColor, labelBoxBkgColor, labelBoxBorderColor, activationBkgColor via secondaryColor). No classDef or linkStyle is available for sequence diagrams.

When requesting a sequence diagram, replace the diagram type and add these constraints:

```
DIAGRAM TYPE: sequenceDiagram

ADDITIONAL SEQUENCE RULES:
- Use the same YAML frontmatter (it includes actor and signal theme variables).
- Keep participant count tight — sequence diagrams degrade above 6–8 participants.
- Use concise message labels.
- Use Note over / Note right of for callouts.
- Use alt/opt/loop/par blocks for branching or conditional logic.
- Do not attempt classDef or linkStyle — these are not supported in sequence diagrams.
```

---

## Part 9: Render Safety Checklist

These are the most common reasons Copilot-generated Mermaid fails to render, especially in Microsoft Loop. Scan output for these before pasting.

| Error | What It Looks Like | Fix |
|-------|-------------------|-----|
| HTML in labels | `A["Line 1<br>Line 2"]` | Remove `<br>`, use single-line labels |
| Semicolons | `A --> B;` | Remove semicolons |
| Inline style overrides on nodes | `style A fill:#ff0000` | Remove — classDef handles node styling |
| Invented classDefs | `classDef custom fill:#random` | Remove — use only the approved library |
| Invented colors in subgraph style | `style SUB fill:#8B5CF6` | Replace with nearest approved tier |
| Single-quoted labels | `A['my label']` | Change to `A["my label"]` |
| Special characters in IDs | `my-node`, `node.1` | Change to `my_node`, `node_1` |
| Missing subgraph end | `subgraph Title` without `end` | Add `end` keyword |
| Duplicate node IDs | Two nodes both named `A` | Make unique: `A1`, `A2` |
| Both init + frontmatter | `%%{init}%%` and `---` both present | Use only one |
| Backtick labels | `` A[`label`] `` | Change to `A["label"]` |
| Lowercase "end" as label | `END["end"]` or node text `end` | Rename to "Complete" or "Finish" |
| Unmatched brackets | `A["label)"]` | Ensure all brackets/parens match |
| Accidental circle/cross edges | `A---oB` or `A---xB` | Use standard `A --> B` syntax |

---

## Part 10: Source References

- Mermaid Theme Configuration (v11.13): https://mermaid.ai/open-source/config/theming.html
- Mermaid Configuration / Frontmatter: https://mermaid.ai/open-source/config/configuration.html
- Mermaid Syntax Reference: https://mermaid.js.org/intro/syntax-reference.html
- Mermaid Config Schema: https://mermaid.ai/open-source/config/schema-docs/config.html
- Mermaid Live Editor: https://mermaid.live

---

## Synthesis Notes

This document integrates best-of-breed contributions from four independent analyses:

**From Claude:** The three-layer styling architecture (frontmatter + classDef + subgraph tiers), the semantic class taxonomy decoupled from vendor names, the complete themeVariables extraction from official docs (including sequence diagram variables), the YAML frontmatter vs init directive dual-format approach with Loop fallback guidance, and the structured subgraph tier system.

**From Copilot (M365):** The render-safety contract (aggressive label quoting, single-line init for portability, avoiding HTML in labels), the "no lowercase end" rule, the single-line init as safest cross-surface default, the observation that Microsoft Loop sometimes lags the public Mermaid version, and the specific Copilot failure mode of hallucinating one-off palettes when not constrained.

**From ChatGPT:** The "house style" framing and the practical workflow patterns (thread opener vs context-based generation), the explicit "repair" and "update" prompt patterns for iterative work without style drift, the Prompt Gallery save/reuse recommendation, and the clear separation of "styling is infrastructure, content is dynamic."

**From Perplexity:** The five diagram-family decomposition (architecture, process, sequence, timeline, mindmap) with per-family config recommendations, the flowchart-specific YAML config keys (curve, diagramPadding, nodeSpacing, rankSpacing, wrappingWidth), the timeline cScale variable mapping, the mindmap config block, and the observation that look/layout parameters are currently only documented for flowcharts and state diagrams.

**Design decisions in this synthesis:**
- Standardized on the init directive fallback as single-line only (Copilot's recommendation; validated by Loop rendering behavior)
- Kept semantic class names from Claude's extraction rather than Perplexity's five-category simplification, because BFS diagrams need the governance vocabulary (gate, control, log, question, scope, outOfScope)
- Added the iterative update and repair prompts from ChatGPT/Perplexity as standalone templates
- Did not include flowchart config keys (curve, nodeSpacing, etc.) in the default templates because Microsoft's embedded Mermaid version is unconfirmed and these keys have higher breakage risk in Loop
- Did not include timeline or mindmap packs because those diagram types have narrow styling surfaces and are still marked experimental; they can be added later once validated in the target Copilot surface
