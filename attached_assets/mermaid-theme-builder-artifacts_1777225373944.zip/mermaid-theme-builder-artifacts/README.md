# Mermaid Theme Builder

**Define your brand. Style your diagrams. Stop fighting with LLM outputs.**

Mermaid Theme Builder is a browser-based visual governance tool for Mermaid diagrams. Paste any Mermaid diagram, apply a theme, preview it live, and export styled code, markdown bootstraps, or AI prompt scaffolds.

Built for enterprise architects, technical writers, and AI power users who generate Mermaid diagrams through Claude, ChatGPT, Copilot, Gemini, or Mermaid.ai.

## The Problem

LLMs generate structurally useful Mermaid diagrams that are visually inconsistent. Every diagram gets a different palette. Follow-up prompts are needed to fix colors. Models hallucinate classDef values. Diagram packages lack visual continuity. There is no "theme file" or "template" equivalent for Mermaid prompt workflows.

Mermaid Theme Builder solves this by treating Mermaid styling like a PowerPoint template: fixed theme + fixed role styles + dynamic content = repeatable visual language.

## Features

- Paste Mermaid code, auto-detect diagram family (15+ types: flowchart, sequence, class, state, ER, gantt, pie, git graph, mindmap, timeline, quadrant, journey, block, sankey, XY chart)
- 7 built-in palettes: Ocean Depth, Forest Sage, Slate Ember, Violet Mist, OverKill Hill P3, Glee-fully, AskJamie
- Two-way live color editor with instant preview
- Three export modes: Styled Code, Markdown Bootstrap, Prompt Scaffold
- Optional theme attribution watermark with clickable link
- Render-safety warnings (existing init directives, non-printable chars, long labels)
- 16 example diagrams covering 12 Mermaid-native diagram types
- 100% client-side. No backend, no login, no data leaves your browser.

## Quick Start

```bash
pnpm install
pnpm --filter @workspace/mermaid-theme-builder dev
```

## Built-In Palettes

| Palette | Style | Best For |
|---------|-------|----------|
| Ocean Depth | Deep blues and teals | Technical diagrams |
| Forest Sage | Earthy greens | Process flows |
| Slate Ember | Dark gray + orange | Architecture diagrams |
| Violet Mist | Soft purples | Product and UX flows |
| OverKill Hill P3 | Industrial dark, teal + amber | Enterprise architecture |
| Glee-fully | Warm coral + cream | Tutorials and how-tos |
| AskJamie | Calm aqua + beige | Guides and documentation |

## Project Structure

```
artifacts/mermaid-theme-builder/
  src/
    lib/palettes.ts        # Palette definitions
    lib/detector.ts        # Diagram family detection
    lib/themeEngine.ts     # Theme application + exports
    components/            # React UI components
    pages/ThemeBuilder.tsx  # Main application
  public/examples/         # .mmd example files
```

## Supported Diagram Types

Flowchart, Sequence, Class, State, ER, Gantt, Pie, Git Graph, Mindmap, Timeline, Quadrant, User Journey, Block, Sankey, XY Chart, Requirement, C4 (Context/Container/Component/Deployment), ZenUML, Packet, Architecture, Kanban.

## Roadmap

- **V0.2-alpha**: Brand presets, showcase diagram, watermark attribution, example library
- **V1.0**: Family-specific themeVariables, font selector, 33 example diagrams, design system docs
- **V1.5**: Model-specific prompt packs (ChatGPT, Claude, Copilot, Mermaid.ai)
- **V2.0**: Two-way composer with extract mode, bidirectional color binding, diff view

## License

MIT

## Links

- **Project Page**: [overkillhill.com/projects/mermaid-theme-builder](https://overkillhill.com/projects/mermaid-theme-builder/)
- **OverKill Hill**: [overkillhill.com](https://overkillhill.com)
- **Glee-fully**: [glee-fully.tools](https://glee-fully.tools)
- **AskJamie**: [askjamie.bot](https://askjamie.bot)

## Disclaimer

Mermaid Theme Builder is a personal OverKill Hill P3 project by Jamie Hill. It is not affiliated with Builders FirstSource, BFS, Mermaid, Mermaid Chart, or Mermaid.ai.
