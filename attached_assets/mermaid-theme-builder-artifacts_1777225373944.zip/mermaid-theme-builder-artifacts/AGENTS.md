# AGENTS.md — Mermaid Theme Builder

## Brand Separation Directive (permanent, non-negotiable)

This project is a personal open-source tool by Jamie Hill (OverKill Hill / OKHP3).
It is NOT affiliated with any employer, including Builders FirstSource (BFS).

When generating code, documentation, comments, or examples for this repository:
- Never reference BFS, Builders FirstSource, or any employer brand.
- Never use these hex values as preset colors: #00205B, #003087, #002F86, #B3C1DB, #D6E5F9, #D0D0CE, #C8102E.
- Never use "BFS Light" or similar employer-derived preset names.
- All preset palettes must be original compositions or derived from the author's personal web properties (overkillhill.com, glee-fully.tools, askjamie.bot).
- Example diagrams must use generic, non-employer content (e.g., generic architecture, sample workflows, placeholder systems).
- The OverKill Hill brand identity (teal #1C3A34, olive, ochre, rust, amber #E6A03C, dark surface #111827) is the author's personal brand and IS acceptable.

This directive is permanent and applies to all contributions, generated code, and documentation in this repository.

## Acceptable Brand Presets

- OverKill Hill P3: teal #1C3A34, amber #E6A03C, dark surface #111827, paper cream #F6F2EE
- Glee-fully: coral #D94F63, paper cream #F6F2EE, teal #2D6F7E
- AskJamie: teal #2D6F7E, beige #EDE9E3, aqua #4A9BAD
- Generic presets: Ocean Depth, Forest Sage, Slate Ember, Violet Mist

## Technical Context

- Static browser-only tool. No backend, no login, no API calls.
- Mermaid.js ^11.14.0 via npm. Do not fork mermaid.
- React + TypeScript + Vite + Tailwind CSS.
- Deploy target: GitHub Pages (static build output).
- The app lives at: `artifacts/mermaid-theme-builder/`
- The app is NOT a Mermaid editor, NOT a Mermaid.ai clone, NOT affiliated with Mermaid Chart Inc.

## Product Scope

Mermaid Theme Builder is a visual governance utility:
1. Paste Mermaid code, auto-detect diagram family
2. Select or customize a color palette
3. Preview the themed result live
4. Export styled code, markdown bootstrap, or AI prompt scaffold

It does NOT:
- Replace Mermaid renderers
- Require login, storage, or backend services
- Make AI API calls (V1)
- Claim to be BPMN-compliant or notation-standards-compliant
