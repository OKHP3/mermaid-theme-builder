# REPLIT: Mermaid Theme Builder — V0.2 Alpha Completion Sprint

**Paste this entire prompt into your Replit chat. It contains all changes needed to reach V0.2-alpha completion in one session.**

---

## IDENTITY (read before every change)

This project is a personal OverKill Hill P3 project by Jamie Hill. NOT associated with any employer including Builders FirstSource (BFS). Reject BFS hex values (#00205B, #003087, #002F86, #B3C1DB, #D6E5F9, #D0D0CE, #C8102E) if encountered anywhere.

---

## TASK 1: Add three brand palette presets

Open `artifacts/mermaid-theme-builder/src/lib/palettes.ts` and ADD these three palettes to the `BUILTIN_PALETTES` array AFTER the existing four (Ocean Depth, Forest Sage, Slate Ember, Violet Mist). Do NOT remove the existing four.

```typescript
  {
    id: "overkill-hill",
    name: "OverKill Hill P³",
    description: "Industrial dark mode with teal and amber forge accents — bold, high-contrast, built for architecture diagrams",
    colors: [
      { key: "primaryColor", label: "Primary (nodes)", value: "#1C3A34" },
      { key: "primaryTextColor", label: "Primary text", value: "#F6F2EE" },
      { key: "primaryBorderColor", label: "Primary border", value: "#E6A03C" },
      { key: "lineColor", label: "Lines & arrows", value: "#2D6F7E" },
      { key: "secondaryColor", label: "Secondary nodes", value: "#2D6F7E" },
      { key: "tertiaryColor", label: "Tertiary nodes", value: "#F6F2EE" },
      { key: "background", label: "Background", value: "#111827" },
      { key: "mainBkg", label: "Main background", value: "#1C3A34" },
      { key: "nodeBorder", label: "Node border", value: "#E6A03C" },
      { key: "clusterBkg", label: "Cluster background", value: "#161b22" },
      { key: "titleColor", label: "Title color", value: "#E6A03C" },
      { key: "edgeLabelBackground", label: "Edge label bg", value: "#111827" },
      { key: "fontFamily", label: "Font family", value: "Impact, Inter, system-ui, sans-serif" },
    ],
  },
  {
    id: "glee-fully",
    name: "Glee-fully",
    description: "Warm and playful with coral and cream — approachable, energetic, great for how-to flows and tutorials",
    colors: [
      { key: "primaryColor", label: "Primary (nodes)", value: "#D94F63" },
      { key: "primaryTextColor", label: "Primary text", value: "#FFFFFF" },
      { key: "primaryBorderColor", label: "Primary border", value: "#B03A4D" },
      { key: "lineColor", label: "Lines & arrows", value: "#2D6F7E" },
      { key: "secondaryColor", label: "Secondary nodes", value: "#2D6F7E" },
      { key: "tertiaryColor", label: "Tertiary nodes", value: "#F6F2EE" },
      { key: "background", label: "Background", value: "#F6F2EE" },
      { key: "mainBkg", label: "Main background", value: "#FDEAED" },
      { key: "nodeBorder", label: "Node border", value: "#D94F63" },
      { key: "clusterBkg", label: "Cluster background", value: "#FFF5F0" },
      { key: "titleColor", label: "Title color", value: "#D94F63" },
      { key: "edgeLabelBackground", label: "Edge label bg", value: "#F6F2EE" },
      { key: "fontFamily", label: "Font family", value: "Trebuchet MS, Calibri, sans-serif" },
    ],
  },
  {
    id: "askjamie",
    name: "AskJamie",
    description: "Calm mid-century tones with muted aquas and beige — clean, readable, ideal for guides and documentation",
    colors: [
      { key: "primaryColor", label: "Primary (nodes)", value: "#2D6F7E" },
      { key: "primaryTextColor", label: "Primary text", value: "#FFFFFF" },
      { key: "primaryBorderColor", label: "Primary border", value: "#1C5361" },
      { key: "lineColor", label: "Lines & arrows", value: "#4A9BAD" },
      { key: "secondaryColor", label: "Secondary nodes", value: "#8FBFC9" },
      { key: "tertiaryColor", label: "Tertiary nodes", value: "#F6F2EE" },
      { key: "background", label: "Background", value: "#F6F2EE" },
      { key: "mainBkg", label: "Main background", value: "#E0EEEF" },
      { key: "nodeBorder", label: "Node border", value: "#2D6F7E" },
      { key: "clusterBkg", label: "Cluster background", value: "#EDE9E3" },
      { key: "titleColor", label: "Title color", value: "#1C5361" },
      { key: "edgeLabelBackground", label: "Edge label bg", value: "#F6F2EE" },
      { key: "fontFamily", label: "Font family", value: "Georgia, Calibri, serif" },
    ],
  },
```

Then update the palette selector grid in `ThemeBuilder.tsx` to handle 7 presets. Change the grid from `grid-cols-2` to a layout that accommodates 7 items cleanly (e.g., `grid-cols-2 sm:grid-cols-3 lg:grid-cols-4` or a scrollable horizontal list).

---

## TASK 2: Replace the default sample diagram

In `artifacts/mermaid-theme-builder/src/pages/ThemeBuilder.tsx`, replace the existing `SAMPLE_CODE` constant with this showcase diagram. This is a validated, render-safe Mermaid flowchart that demonstrates subgraphs, multiple shape types, clickable links, animated edges, and 26 classDef classes:

```typescript
const SAMPLE_CODE = `flowchart LR
%% Theme: OKH Protocol Dark
%% Created with: Mermaid Theme Builder by OverKill Hill P3

START@{ shape: stadium, label: "Random Thought Enters the Machine" }:::origin
SPARK@{ shape: bolt, label: "Spark" }:::hot
LEDGER@{ shape: docs, label: "Notes, Threads, Prompts" }:::doc
COUNCIL@{ shape: braces, label: "Council of AIs: useful or just shiny?" }:::council
DECIDE@{ shape: diamond, label: "Worth Overdoing?" }:::decision

START e_start@==> SPARK
SPARK e_collect@--> LEDGER
LEDGER e_interrogate@--> COUNCIL
COUNCIL e_decide@--> DECIDE

DECIDE -- "No, park it" --> GRAVEYARD@{ shape: bow-rect, label: "Idea Graveyard" }:::muted
GRAVEYARD -. "ferments" .-> SPARK
DECIDE -- "Yes, overdo it" --> THESIS@{ shape: hex, label: "Name the Pain" }:::okh

subgraph SG1["1. Sequence Engine: Context Distillation"]
direction TB
  S1A@{ shape: circle, label: "Input" }:::sequence
  S1B@{ shape: stadium, label: "Voice Riff" }:::sequence
  S1C@{ shape: doc, label: "Messy Transcript" }:::doc
  S1D@{ shape: div-rect, label: "Extract Claims" }:::sequence
  S1E@{ shape: notch-rect, label: "Reusable Thesis Card" }:::artifact
  S1A --> S1B --> S1C --> S1D --> S1E
end

subgraph SG2["2. Timeline Forge: Maybe to Momentum"]
direction TB
  T0@{ shape: sm-circ, label: "T+0" }:::timeline
  T1@{ shape: flag, label: "T+2 Name Product" }:::timeline
  T2@{ shape: hourglass, label: "T+6 Debate Scope" }:::timeline
  T3@{ shape: doc, label: "T+9 PRD Packet" }:::timeline
  T4@{ shape: framed-circle, label: "T+12 Prototype" }:::artifact
  T0 --> T1 --> T2 --> T3 --> T4
end

subgraph SG3["3. Brand Gravity Well"]
direction TB
  M0@{ shape: dbl-circ, label: "Personal Ecosystem" }:::brand
  M1@{ shape: curv-trap, label: "OverKill Hill P3" }:::okh
  M2@{ shape: stadium, label: "AskJamie" }:::askjamie
  M3@{ shape: stadium, label: "Glee-fully" }:::glee
  M4@{ shape: comment, label: "No BFS. No employer bleed." }:::warning
  M0 --> M1
  M0 --> M2
  M0 --> M3
  M0 --> M4
end

subgraph SG4["4. Theme Builder Runtime"]
direction TB
  A1@{ shape: lean-r, label: "Paste Mermaid" }:::input
  A2@{ shape: cyl, label: "Palette Store" }:::data
  A3@{ shape: hex, label: "Theme Engine" }:::engine
  A4@{ shape: curv-trap, label: "Live Preview" }:::preview
  A5@{ shape: lean-l, label: "Copy / Export" }:::output
  A1 --> A3
  A2 --> A3
  A3 --> A4
  A3 --> A5
end

subgraph SG5["5. Apply, Repair, Repeat"]
direction TB
  P1@{ shape: lean-r, label: "Bland Diagram" }:::raw
  P2@{ shape: trap-t, label: "Detect Family" }:::process
  P3@{ shape: diamond, label: "Strong Support?" }:::decision
  P4@{ shape: tag-rect, label: "Full Theme" }:::success
  P5@{ shape: notch-rect, label: "Generic Only" }:::caution
  P6@{ shape: dbl-circ, label: "Styled Artifact" }:::artifact
  P1 --> P2 --> P3
  P3 -- "High" --> P4 --> P6
  P3 -- "Beta" --> P5 --> P6
end

subgraph SG6["6. Governance: Safety and Attribution"]
direction TB
  G1@{ shape: hex, label: "Render Safety Scan" }:::govern
  G2@{ shape: cyl, label: "Theme Metadata" }:::data
  G3@{ shape: comment, label: "Source Comments: ON" }:::note
  G4@{ shape: flag, label: "Export Bootstrap" }:::artifact
  G1 --> G2
  G2 --> G3
  G2 --> G4
end

THESIS e_s1@--> SG1
SG1 e_s2@--> SG2
SG2 e_s3@--> SG3
SG3 e_s4@--> SG4
SG4 e_s5@--> SG5
SG5 e_s6@--> SG6

SG6 e_ship@==> SHIP@{ shape: dbl-circ, label: "Ship it. Then sharpen it." }:::ship

OKH_LINK@{ shape: curv-trap, label: "overkillhill.com" }:::okhLink
GLEE_LINK@{ shape: curv-trap, label: "glee-fully.tools" }:::gleeLink
ASK_LINK@{ shape: curv-trap, label: "askjamie.bot" }:::askLink

SHIP --> OKH_LINK
SHIP --> GLEE_LINK
SHIP --> ASK_LINK

FOOTNOTE@{ shape: text, label: "Mermaid Theme Builder | OKH Protocol Dark | v0.2-alpha" }:::credit
SHIP -.-> FOOTNOTE

click OKH_LINK "https://overkillhill.com" _blank
click GLEE_LINK "https://glee-fully.tools" _blank
click ASK_LINK "https://askjamie.bot" _blank
click FOOTNOTE "https://overkillhill.com/projects/mermaid-theme-builder/" _blank`;
```

Also add a second simpler sample so users have a choice. Add this above the showcase:

```typescript
const SIMPLE_SAMPLE = `flowchart TD
    A[User Request] --> B{Validate Input}
    B -->|Valid| C[Process Request]
    B -->|Invalid| D[Return Error]
    C --> E[Fetch Data]
    E --> F{Data Found?}
    F -->|Yes| G[Format Response]
    F -->|No| H[Return 404]
    G --> I[Send Response]`;
```

Add a "Load example" dropdown or two buttons ("Simple Example" / "Showcase") where the current single "Load example" button is.

---

## TASK 3: Add theme watermark toggle

In `ThemeBuilder.tsx`, add these UI elements in the export bar area (the bottom bar with the copy buttons):

1. A toggle switch labeled **"Include attribution"** (default: ON)
2. A small text input labeled **"Theme name"** pre-filled with the current preset name

In `themeEngine.ts`, update `generateThemedCode()` to accept watermark options. When the toggle is ON, append this block to the generated output (before the closing of the diagram):

```typescript
// Add to generateThemedCode options interface
export interface WatermarkOptions {
  enabled: boolean;
  themeName: string;
  toolUrl?: string;
}

// Append this when watermark is enabled:
const watermarkBlock = `
    MTB_ATTR(["Styled with ${themeName} via Mermaid Theme Builder"])
    classDef mtb_watermark fill:none,stroke:#888,stroke-width:1px,color:#888,font-size:10px
    class MTB_ATTR mtb_watermark
    click MTB_ATTR "${toolUrl || 'https://overkillhill.com/projects/mermaid-theme-builder/'}" _blank`;
```

When watermark is OFF, do not append anything.

---

## TASK 4: Add version comment to detector

At the top of `artifacts/mermaid-theme-builder/src/lib/detector.ts`, add this comment on line 1:

```typescript
// Diagram patterns aligned to mermaid v11.14.0 — update when new types ship
```

---

## TASK 5: Add footer notice and project links

In `ThemeBuilder.tsx`, add a small footer below the export bar:

```tsx
<footer className="border-t border-border bg-card/20 px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
  <span>
    Mermaid Theme Builder is not affiliated with Mermaid, Mermaid Chart, or Mermaid.ai.
    A personal <a href="https://overkillhill.com" target="_blank" rel="noopener" className="underline hover:text-foreground">OverKill Hill P³</a> project.
  </span>
  <span className="flex items-center gap-3">
    <a href="https://github.com/OKHP3/mermaid-theme-builder" target="_blank" rel="noopener" className="underline hover:text-foreground">GitHub</a>
    <a href="https://overkillhill.com/projects/mermaid-theme-builder/" target="_blank" rel="noopener" className="underline hover:text-foreground">Project Page</a>
  </span>
</footer>
```

---

## TASK 6: Create LICENSE file

Create `LICENSE` in the repository root with MIT license text:

```
MIT License

Copyright (c) 2026 Jamie Hill / OverKill Hill P³

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

---

## TASK 7: Create AGENTS.md

Create `AGENTS.md` in the repository root:

```markdown
# AGENTS.md — Mermaid Theme Builder

## Brand Separation Directive (permanent, non-negotiable)

This project is a personal open-source tool by Jamie Hill (OverKill Hill / OKHP3).
It is NOT affiliated with any employer, including Builders FirstSource (BFS).

When generating code, documentation, comments, or examples for this repository:
- Never reference BFS, Builders FirstSource, or any employer brand.
- Never use these hex values as preset colors: #00205B, #003087, #002F86, #B3C1DB, #D6E5F9, #D0D0CE, #C8102E.
- All preset palettes must be original compositions or derived from the author's personal web properties (overkillhill.com, glee-fully.tools, askjamie.bot).
- Example diagrams must use generic, non-employer content.

## Acceptable Brand Presets

- OverKill Hill P3: teal #1C3A34, amber #E6A03C, dark surface #111827
- Glee-fully: coral #D94F63, paper cream #F6F2EE, teal #2D6F7E
- AskJamie: teal #2D6F7E, beige #EDE9E3, aqua #4A9BAD
- Generic presets: Ocean Depth, Forest Sage, Slate Ember, Violet Mist

## Technical Context

- Static browser-only tool. No backend, no login, no API calls.
- Mermaid.js ^11.14.0 via npm. Do not fork mermaid.
- React + TypeScript + Vite + Tailwind CSS.
- Deploy target: GitHub Pages (static build output).
- The app lives at: artifacts/mermaid-theme-builder/
```

---

## TASK 8: Update README.md

Replace the current 2-line README.md with:

```markdown
# Mermaid Theme Builder

**Define your brand. Style your diagrams. Stop fighting with LLM outputs.**

Mermaid Theme Builder is a browser-based visual governance tool for Mermaid diagrams. Paste any Mermaid diagram, apply a theme, preview it live, and export styled code, markdown bootstraps, or AI prompt scaffolds.

Built for enterprise architects, technical writers, and AI power users who generate Mermaid diagrams through Claude, ChatGPT, Copilot, Gemini, or Mermaid.ai.

## Features

- Paste Mermaid code, auto-detect diagram family (15 types)
- 7 built-in palettes: Ocean Depth, Forest Sage, Slate Ember, Violet Mist, OverKill Hill P3, Glee-fully, AskJamie
- Two-way live color editor with instant preview
- Three export modes: Styled Code, Markdown Bootstrap, Prompt Scaffold
- Render-safety warnings (existing init directives, non-printable chars, long labels)
- Optional theme attribution watermark with clickable link
- 100% client-side. No backend, no login, no data leaves your browser.

## Quick Start

```bash
pnpm install
pnpm --filter @workspace/mermaid-theme-builder dev
```

## Supported Diagram Types

Flowchart, Sequence, Class, State, ER, Gantt, Pie, Git Graph, Mindmap, Timeline, Quadrant, User Journey, Block, Sankey, XY Chart.

## License

MIT

## Disclaimer

Mermaid Theme Builder is a personal OverKill Hill P3 project by Jamie Hill. It is not affiliated with Builders FirstSource, BFS, Mermaid, Mermaid Chart, or Mermaid.ai.
```

---

## TASK 9: Add GitHub Pages workflow

Create `.github/workflows/pages.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "pages"
  cancel-in-progress: false

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v4
        with:
          version: 9
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: pnpm
      - run: pnpm install --frozen-lockfile
      - run: pnpm --filter @workspace/mermaid-theme-builder build
        env:
          PORT: "3000"
          BASE_PATH: "/mermaid-theme-builder"
      - uses: actions/upload-pages-artifact@v3
        with:
          path: artifacts/mermaid-theme-builder/dist/public

  deploy:
    needs: build
    runs-on: ubuntu-latest
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    steps:
      - id: deployment
        uses: actions/deploy-pages@v4
```

---

## TASK 10: Create examples directory with Tier 1 files

Create `artifacts/mermaid-theme-builder/public/examples/` and add these files:

### flowchart-basic.mmd
```
flowchart TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Process A]
    B -->|No| D[Process B]
    C --> E[End]
    D --> E
```

### sequence-basic.mmd
```
sequenceDiagram
    participant U as User
    participant S as System
    participant D as Database
    U->>S: Submit Request
    S->>D: Query Data
    D-->>S: Return Results
    S-->>U: Display Response
```

### class-basic.mmd
```
classDiagram
    class ThemeEngine {
        +Palette palette
        +generateCode(input)
        +applyTheme(code, palette)
    }
    class Palette {
        +String id
        +String name
        +ThemeColor[] colors
    }
    class ThemeColor {
        +String key
        +String label
        +String value
    }
    ThemeEngine --> Palette
    Palette --> ThemeColor
```

### gantt-basic.mmd
```
gantt
    title Mermaid Theme Builder Roadmap
    dateFormat YYYY-MM-DD
    section Alpha
        Core UI           :done, a1, 2026-04-01, 14d
        Palette presets    :active, a2, 2026-04-15, 7d
        Showcase diagram   :a3, after a2, 5d
    section V1.0
        Example library    :b1, after a3, 10d
        Prompt packs       :b2, after b1, 7d
        GitHub Pages deploy:b3, after b2, 3d
```

### overkill-rube-goldberg-wow.mmd
(Copy the full showcase diagram from Task 2's SAMPLE_CODE content into this file, without the TypeScript string wrapper)

---

## PRIORITY ORDER

Execute in this order:
1. Task 1 (brand presets)
2. Task 2 (showcase sample)
3. Task 6 (LICENSE)
4. Task 7 (AGENTS.md)
5. Task 8 (README)
6. Task 5 (footer)
7. Task 3 (watermark toggle)
8. Task 4 (version comment)
9. Task 10 (examples directory)
10. Task 9 (GitHub Pages workflow)

After all tasks, commit with message: `feat: V0.2-alpha — brand presets, showcase, watermark, examples, deploy pipeline`

---

## BRAND SEPARATION RULES (permanent)

- No BFS, Builders FirstSource, or employer references anywhere
- Reject BFS hex values: #00205B, #003087, #002F86, #B3C1DB, #D6E5F9, #D0D0CE, #C8102E
- Acceptable presets: Ocean Depth, Forest Sage, Slate Ember, Violet Mist, OverKill Hill P3, Glee-fully, AskJamie
- Example diagrams use generic content only
- Flag any BFS reference to the user before proceeding
