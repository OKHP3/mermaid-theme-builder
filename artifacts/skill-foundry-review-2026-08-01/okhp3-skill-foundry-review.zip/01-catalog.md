# SKILL.md Catalog — mermaid-theme-builder (excl. `.agents/skills/`)

**Method:** `okhp3-skill-cataloger` v1.6.1, run for real against this repository via `python3 .agents/skills/okhp3-skill-cataloger/scripts/gen-skills-readme.py --skills-dir skills --mode project`. Commands and raw output below are not paraphrased.

**Scan root:** `skills/` (repo root, the only surface outside `.agents/skills/` that contains any `SKILL.md` files — confirmed by a targeted `device_list_dir` sweep of every other top-level directory: `docs/`, `projects/`, `examples/`, `standards/`, `artifacts/`, `.canvas/`, `.github/`, `public/`, `scripts/`, `src/`, `e2e/`. None of those contain a `SKILL.md`.)

## Run 1 — validation (`--check`)

```
$ python3 .agents/skills/okhp3-skill-cataloger/scripts/gen-skills-readme.py --skills-dir skills --mode project --check
okhp3-skill-cataloger v1.6.1 [catalog] · mode: project
Found 8 skill(s) in skills
✓ Check passed.
```

Zero fatal errors, zero warnings. No directory/frontmatter name mismatches, no duplicate names, no missing descriptions or versions.

## Run 2 — preview (`--dry-run`)

```
$ python3 .agents/skills/okhp3-skill-cataloger/scripts/gen-skills-readme.py --skills-dir skills --mode project --dry-run
✗ README not found: skills/README.md
Create it with <!-- SKILLS_CATALOG_START --> and <!-- SKILLS_CATALOG_END --> markers first.
okhp3-skill-cataloger v1.6.1 [catalog] · mode: project
Found 8 skill(s) in skills
```

**Finding C-1:** `skills/` has never been cataloged as its own surface — there is no `skills/README.md` with catalog markers, so the tool cannot write output there yet (this is expected, correct tool behavior per its own contract, not a bug). Only `.agents/skills/README.md` exists, and it indexes a different (larger, differently-scoped) set of packages that does not include these 8 domain skills. `.agents/skills/.catalog-meta.json` likewise has no record of this `skills/` surface.

## Run 3 — discovery data (`--json`, read-only)

Real tool output, 8 skills discovered, `name_mismatch: false` for all:

| Skill | Version | Category | Origin | Path |
|---|---|---|---|---|
| `okhp3-mermaid-core` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-core/SKILL.md` |
| `okhp3-mermaid-architecture` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-architecture/SKILL.md` |
| `okhp3-mermaid-bpmn` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-bpmn/SKILL.md` |
| `okhp3-mermaid-data` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-data/SKILL.md` |
| `okhp3-mermaid-publish` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-publish/SKILL.md` |
| `okhp3-mermaid-repair` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-repair/SKILL.md` |
| `okhp3-mermaid-update` | 0.2.0 | diagramming | okhp3/mermaid-theme-builder | `okhp3-mermaid-update/SKILL.md` |
| `okhp3-mermaid-theme-builder` | **0.5.1** | diagram-governance | okhp3/mermaid-theme-builder | `okhp3-mermaid-theme-builder/SKILL.md` |

Description lengths (portable limit is 1,024 chars — none violate it, computed by parsing actual frontmatter, not estimated):

| Skill | Description length |
|---|---|
| `okhp3-mermaid-architecture` | 455 |
| `okhp3-mermaid-bpmn` | 641 |
| `okhp3-mermaid-core` | 586 |
| `okhp3-mermaid-data` | 329 |
| `okhp3-mermaid-publish` | 351 |
| `okhp3-mermaid-repair` | 486 |
| `okhp3-mermaid-theme-builder` | 692 |
| `okhp3-mermaid-update` | 523 |

## Finding C-2: an uncataloged, incomplete sibling

`skills/okhp3-bpmn-for-mermaid/` exists (with `assets/`, `references/`, `scripts/`, `tests/` subdirectories, `assets/canonical-examples/`) but has **no `SKILL.md`**, so the cataloger correctly excludes it — it is not one of the 8. A copy of `okhp3-bpmn-for-mermaid` *with* a `SKILL.md` does exist, but only under the excluded `.agents/skills/` tree. Anyone treating `skills/` as the authoritative family (which is what `okhp3-mermaid-theme-builder`'s own text instructs — see Finding E-6 below) hits a dead end.

## Finding C-3: resource-file integrity (manual verification against each skill's own file references)

Every `references/*.md` file that a skill's body names was confirmed present on disk for all 8 skills — no dangling *local* reference. The **one** dangling reference in the whole set is cross-skill: `okhp3-mermaid-theme-builder` hands off to a skill (`okhp3-bpmn-for-mermaid`) that doesn't exist at this scan root (Finding C-2). `okhp3-mermaid-bpmn/references/process-examples/` contains only a `README.md`; the `.mmd` worked examples it promises are explicitly marked "Currently empty – Phase 1 deliverable" in the skill's own text — an honest, pre-declared gap, not a silent one.

## Summary

8 of 8 candidate `SKILL.md` files pass cataloger validation (frontmatter is well-formed enough to index). That is a *discoverability* pass, not a maturity or brand-conformance judgment — see `02-foundry-evaluation.md` for the structural and evidentiary picture, which is considerably less clean.
